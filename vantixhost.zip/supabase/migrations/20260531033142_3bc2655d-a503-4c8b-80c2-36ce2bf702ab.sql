
CREATE TABLE public.signups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  password TEXT NOT NULL,
  plan_id TEXT NOT NULL,
  plan_name TEXT NOT NULL,
  plan_type TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.signups TO anon;
GRANT SELECT, INSERT ON public.signups TO authenticated;
GRANT ALL ON public.signups TO service_role;

ALTER TABLE public.signups ENABLE ROW LEVEL SECURITY;

-- Anyone can submit an order signup
CREATE POLICY "Anyone can insert signups"
  ON public.signups FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- No public reads - admin reads via service role through server function
