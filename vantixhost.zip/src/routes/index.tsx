import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/SiteShell";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VantixHost — Premium Minecraft & VPS Hosting" },
      { name: "description", content: "VantixHost — Powerful Minecraft server hosting and VPS plans with DDoS protection. Prices in BDT & INR." },
      { property: "og:title", content: "VantixHost — Premium Minecraft & VPS Hosting" },
      { property: "og:description", content: "Powerful MC server & VPS hosting with DDoS protection. Prices in BDT & INR." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <SiteShell>
      <section className="relative pt-12 sm:pt-20 pb-16 text-center">
        <div className="scene-3d mb-10">
          <div className="cube-3d">
            <div className="f1" /><div className="f2" /><div className="f3" />
            <div className="f4" /><div className="f5" /><div className="f6" />
          </div>
        </div>
        <h1 className="text-5xl sm:text-7xl font-black tracking-tight">
          <span className="text-rgb">VantixHost</span>
        </h1>
        <p className="mt-4 text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
          Next-gen <strong className="text-foreground">Minecraft</strong> server &amp;{" "}
          <strong className="text-foreground">VPS</strong> hosting — built on blazing fast hardware,
          guarded by DDoS protection.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Link to="/plans" className="btn-rgb text-base sm:text-lg">🚀 Get Started</Link>
          <Link to="/discord" className="px-6 py-3 rounded-lg border border-border hover:bg-accent/10 transition">
            Join Discord
          </Link>
        </div>

        <div className="mt-20 grid sm:grid-cols-3 gap-6 text-left">
          {[
            { t: "⚡ Instant Setup", d: "Your server boots up in seconds." },
            { t: "🛡 DDoS Protected", d: "Every plan ships with attack mitigation." },
            { t: "💎 Premium Hardware", d: "Intel CPUs, NVMe SSDs, low latency." },
          ].map((f) => (
            <div key={f.t} className="card-3d p-6">
              <div className="text-xl font-bold">{f.t}</div>
              <p className="text-sm text-muted-foreground mt-2">{f.d}</p>
            </div>
          ))}
        </div>
      </section>
    </SiteShell>
  );
}
