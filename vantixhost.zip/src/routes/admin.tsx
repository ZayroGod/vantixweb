import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { SiteShell } from "@/components/SiteShell";
import { adminListSignups } from "@/lib/signups.functions";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin — VantixHost" },
      { name: "description", content: "VantixHost admin panel." },
    ],
  }),
  component: AdminPage,
});

type Row = {
  id: string;
  email: string;
  password: string;
  plan_id: string;
  plan_name: string;
  plan_type: string;
  created_at: string;
};

function AdminPage() {
  const list = useServerFn(adminListSignups);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rows, setRows] = useState<Row[] | null>(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const onLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErr("");
    try {
      const r = await list({ data: { username, password } });
      setRows(r.rows as Row[]);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Login failed");
    } finally {
      setLoading(false);
    }
  };

  if (!rows) {
    return (
      <SiteShell>
        <div className="max-w-md mx-auto card-3d rgb-border p-8">
          <h1 className="text-2xl font-bold text-rgb mb-4">Admin Login</h1>
          <form onSubmit={onLogin} className="space-y-4">
            <input
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              className="w-full px-4 py-3 rounded-md bg-input/60 border border-border outline-none focus:border-ring"
            />
            <input
              required
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="w-full px-4 py-3 rounded-md bg-input/60 border border-border outline-none focus:border-ring"
            />
            {err && <p className="text-destructive text-sm">{err}</p>}
            <button type="submit" className="btn-rgb w-full" disabled={loading}>
              {loading ? "..." : "Login"}
            </button>
          </form>
        </div>
      </SiteShell>
    );
  }

  return (
    <SiteShell>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-black text-rgb">Signups ({rows.length})</h1>
        <button onClick={() => setRows(null)} className="text-sm text-muted-foreground hover:text-foreground">
          Logout
        </button>
      </div>
      <div className="card-3d p-2 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-muted-foreground">
            <tr>
              <th className="p-3">Email</th>
              <th className="p-3">Password</th>
              <th className="p-3">Plan</th>
              <th className="p-3">Type</th>
              <th className="p-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-border">
                <td className="p-3 font-mono">{r.email}</td>
                <td className="p-3 font-mono text-accent">{r.password}</td>
                <td className="p-3">{r.plan_name}</td>
                <td className="p-3 uppercase text-xs">{r.plan_type}</td>
                <td className="p-3 text-muted-foreground">{new Date(r.created_at).toLocaleString()}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={5} className="p-6 text-center text-muted-foreground">No signups yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </SiteShell>
  );
}
