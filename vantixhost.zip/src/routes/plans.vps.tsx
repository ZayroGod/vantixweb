import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/SiteShell";
import { PlanCard } from "@/components/PlanCard";
import { VPS_PLANS } from "@/lib/plans";

export const Route = createFileRoute("/plans/vps")({
  head: () => ({
    meta: [
      { title: "VPS Plans — VantixHost" },
      { name: "description", content: "VPS hosting plans with HVM panel, IPv4, DDoS protection, Intel CPUs. From ৳50 / ₹50." },
    ],
  }),
  component: VpsPlansPage,
});

function VpsPlansPage() {
  return (
    <SiteShell>
      <div className="text-center mb-10">
        <h1 className="text-4xl sm:text-5xl font-black"><span className="text-rgb">VPS Plans</span></h1>
        <p className="mt-3 text-muted-foreground">
          Every VPS ships with <strong className="text-foreground">HVM panel</strong>, dedicated{" "}
          <strong className="text-foreground">IPv4</strong>, <strong className="text-foreground">DDoS protection</strong>,
          and powerful <strong className="text-foreground">Intel</strong> CPUs.
        </p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {VPS_PLANS.map((p) => <PlanCard key={p.id} plan={p} />)}
      </div>
    </SiteShell>
  );
}
