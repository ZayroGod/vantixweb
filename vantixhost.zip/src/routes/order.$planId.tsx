import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { SiteShell } from "@/components/SiteShell";
import { findPlan, DISCORD_INVITE } from "@/lib/plans";
import { createSignup } from "@/lib/signups.functions";

export const Route = createFileRoute("/order/$planId")({
  head: () => ({
    meta: [
      { title: "Order — VantixHost" },
      { name: "description", content: "Complete your VantixHost order signup." },
    ],
  }),
  component: OrderPage,
});

function OrderPage() {
  const { planId } = useParams({ from: "/order/$planId" });
  const plan = findPlan(planId);
  const submit = useServerFn(createSignup);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [errMsg, setErrMsg] = useState("");

  if (!plan) {
    return (
      <SiteShell>
        <div className="card-3d p-8 text-center">
          <h1 className="text-2xl font-bold">Plan not found</h1>
          <Link to="/plans" className="btn-rgb inline-flex mt-4">Browse plans</Link>
        </div>
      </SiteShell>
    );
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    setErrMsg("");
    try {
      await submit({
        data: {
          email: email.trim(),
          password,
          plan_id: plan.id,
          plan_name: plan.name,
          plan_type: plan.type,
        },
      });
      setStatus("done");
    } catch (err) {
      setStatus("error");
      setErrMsg(err instanceof Error ? err.message : "Failed to submit");
    }
  };

  if (status === "done") {
    return (
      <SiteShell>
        <div className="max-w-xl mx-auto card-3d rgb-border p-10 text-center">
          <div className="text-5xl mb-3">✅</div>
          <h1 className="text-3xl font-bold text-rgb">Order Received!</h1>
          <p className="text-muted-foreground mt-3">
            Your signup for <strong className="text-foreground">{plan.name}</strong> ({plan.type.toUpperCase()}) is saved.
          </p>
          <p className="mt-6 text-sm text-muted-foreground">
            👇 Next step — join our Discord and create a <strong className="text-foreground">Ticket</strong> to complete purchase.
          </p>
          <a href={DISCORD_INVITE} target="_blank" rel="noreferrer" className="btn-rgb inline-flex mt-6">
            Join Discord & Create Ticket
          </a>
        </div>
      </SiteShell>
    );
  }

  return (
    <SiteShell>
      <div className="max-w-xl mx-auto">
        <div className="card-3d p-8">
          <h1 className="text-3xl font-bold">Sign up to order</h1>
          <p className="text-muted-foreground mt-1">
            Plan: <span className="text-rgb font-bold">{plan.name}</span> · {plan.type.toUpperCase()} ·{" "}
            ৳{plan.priceTk} / ₹{plan.priceInr}
          </p>

          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            <div>
              <label className="block text-sm mb-1 text-muted-foreground">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-md bg-input/60 border border-border outline-none focus:border-ring"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="block text-sm mb-1 text-muted-foreground">Password</label>
              <input
                type="password"
                required
                minLength={4}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-md bg-input/60 border border-border outline-none focus:border-ring"
                placeholder="Choose a password"
              />
            </div>
            {errMsg && <p className="text-destructive text-sm">{errMsg}</p>}
            <button type="submit" className="btn-rgb w-full" disabled={status === "loading"}>
              {status === "loading" ? "Saving..." : "Sign up & Order"}
            </button>
          </form>

          <Link to="/plans" className="block text-center text-sm text-muted-foreground mt-4 hover:text-foreground">
            ← Back to plans
          </Link>
        </div>
      </div>
    </SiteShell>
  );
}
