import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/SiteShell";
import { PlanCard } from "@/components/PlanCard";
import { MC_PLANS } from "@/lib/plans";

export const Route = createFileRoute("/plans/minecraft")({
  head: () => ({
    meta: [
      { title: "Minecraft Server Plans — VantixHost" },
      { name: "description", content: "Minecraft hosting plans: Dirt, Stone, Diamond, Netherite, Powerful. From ৳40 / ₹40." },
    ],
  }),
  component: McPlansPage,
});

function McPlansPage() {
  return (
    <SiteShell>
      <div className="text-center mb-10">
        <h1 className="text-4xl sm:text-5xl font-black"><span className="text-rgb">Minecraft Plans</span></h1>
        <p className="mt-3 text-muted-foreground">Pick your tier — every plan includes DDoS protection.</p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {MC_PLANS.map((p) => <PlanCard key={p.id} plan={p} />)}
      </div>
    </SiteShell>
  );
}
