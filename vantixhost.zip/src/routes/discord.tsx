import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/SiteShell";
import { DISCORD_INVITE } from "@/lib/plans";

export const Route = createFileRoute("/discord")({
  head: () => ({
    meta: [
      { title: "Discord — VantixHost" },
      { name: "description", content: "Join VantixHost on Discord and open a Ticket to buy." },
    ],
  }),
  component: DiscordPage,
});

function DiscordPage() {
  return (
    <SiteShell>
      <div className="max-w-2xl mx-auto card-3d rgb-border p-10 text-center">
        <div className="text-6xl mb-3">💬</div>
        <h1 className="text-4xl font-black text-rgb">Join our Discord</h1>
        <p className="text-muted-foreground mt-3">
          📢 <strong className="text-foreground">Notice:</strong> Click the button below, join our Discord,
          and <strong className="text-foreground">Create a Ticket</strong> to complete your purchase.
        </p>
        <a href={DISCORD_INVITE} target="_blank" rel="noreferrer" className="btn-rgb mt-8 inline-flex text-lg">
          Join Discord
        </a>
        <p className="text-xs text-muted-foreground mt-6 break-all">{DISCORD_INVITE}</p>
      </div>
    </SiteShell>
  );
}
