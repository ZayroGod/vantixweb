import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/SiteShell";

export const Route = createFileRoute("/plans/")({
  head: () => ({
    meta: [
      { title: "Choose a Plan — VantixHost" },
      { name: "description", content: "Choose between Minecraft server plans or VPS plans at VantixHost." },
    ],
  }),
  component: PlansHub,
});

function PlansHub() {
  return (
    <SiteShell>
      <div className="text-center mb-12">
        <h1 className="text-4xl sm:text-5xl font-black"><span className="text-rgb">Pick Your Power</span></h1>
        <p className="mt-3 text-muted-foreground">Two ways to host. Both pure performance.</p>
      </div>
      <div className="grid md:grid-cols-2 gap-8">
        <Link to="/plans/minecraft" className="card-3d rgb-border p-10 text-center group">
          <div className="text-6xl mb-4">⛏️</div>
          <h2 className="text-3xl font-bold">Minecraft Servers</h2>
          <p className="text-muted-foreground mt-2">5 tiers: Dirt → Powerful. DDoS protected.</p>
          <div className="btn-rgb mt-6 inline-flex">Browse MC Plans</div>
        </Link>
        <Link to="/plans/vps" className="card-3d rgb-border p-10 text-center group">
          <div className="text-6xl mb-4">🖥️</div>
          <h2 className="text-3xl font-bold">VPS Plans</h2>
          <p className="text-muted-foreground mt-2">HVM panel, IPv4, DDoS protection, Intel CPUs.</p>
          <div className="btn-rgb mt-6 inline-flex">Browse VPS Plans</div>
        </Link>
      </div>
    </SiteShell>
  );
}
