export type Plan = {
  id: string;
  name: string;
  ram: string;
  cpu: string;
  disk: string;
  extra?: string;
  priceTk: number;
  priceInr: number;
  tier: "dirt" | "stone" | "diamond" | "netherite" | "powerful" | "shorts";
  type: "minecraft" | "vps";
};

export const MC_PLANS: Plan[] = [
  { id: "mc-dirt",      name: "Dirt",      ram: "2 GB",  cpu: "1 vCore", disk: "15 GB",  extra: "DDoS Protection", priceTk: 40,  priceInr: 40,  tier: "dirt",      type: "minecraft" },
  { id: "mc-stone",     name: "Stone",     ram: "4 GB",  cpu: "2 vCore", disk: "30 GB",  extra: "DDoS Protection", priceTk: 80,  priceInr: 80,  tier: "stone",     type: "minecraft" },
  { id: "mc-diamond",   name: "Diamond",   ram: "8 GB",  cpu: "4 vCore", disk: "50 GB",  extra: "DDoS Protection", priceTk: 150, priceInr: 150, tier: "diamond",   type: "minecraft" },
  { id: "mc-netherite", name: "Netherite", ram: "16 GB", cpu: "6 vCore", disk: "100 GB", extra: "DDoS Protection", priceTk: 300, priceInr: 300, tier: "netherite", type: "minecraft" },
  { id: "mc-powerful",  name: "Powerful",  ram: "32 GB", cpu: "8 vCore", disk: "200 GB", extra: "DDoS Protection", priceTk: 500, priceInr: 500, tier: "powerful",  type: "minecraft" },
];

export const VPS_PLANS: Plan[] = [
  { id: "vps-shorts",    name: "Shorts",    ram: "4 GB",  cpu: "1 vCore", disk: "20 GB",  extra: "HVM • IPv4 • DDoS",      priceTk: 50,  priceInr: 50,  tier: "shorts",    type: "vps" },
  { id: "vps-stone",     name: "Stone",     ram: "8 GB",  cpu: "3 vCore", disk: "50 GB",  extra: "HVM • IPv4 • DDoS",      priceTk: 100, priceInr: 100, tier: "stone",     type: "vps" },
  { id: "vps-diamond",   name: "Diamond",   ram: "16 GB", cpu: "4 vCore", disk: "100 GB", extra: "HVM • IPv4 • DDoS",      priceTk: 250, priceInr: 250, tier: "diamond",   type: "vps" },
  { id: "vps-netherite", name: "Netherite", ram: "32 GB", cpu: "8 vCore", disk: "200 GB", extra: "HVM • IPv4 • DDoS",      priceTk: 600, priceInr: 600, tier: "netherite", type: "vps" },
];

export const ALL_PLANS = [...MC_PLANS, ...VPS_PLANS];

export const findPlan = (id: string) => ALL_PLANS.find((p) => p.id === id);

export const DISCORD_INVITE = "https://discord.gg/Rqntbuj3bv";
