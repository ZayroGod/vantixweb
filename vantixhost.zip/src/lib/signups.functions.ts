import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const ADMIN_USER = "admin";
const ADMIN_PASS = "admin1234!";

export const createSignup = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({
      email: z.string().trim().email().max(255),
      password: z.string().min(4).max(200),
      plan_id: z.string().min(1).max(100),
      plan_name: z.string().min(1).max(200),
      plan_type: z.enum(["minecraft", "vps"]),
    }).parse(input),
  )
  .handler(async ({ data }) => {
    const { error } = await supabaseAdmin.from("signups").insert(data);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const adminListSignups = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({
      username: z.string().max(100),
      password: z.string().max(200),
    }).parse(input),
  )
  .handler(async ({ data }) => {
    if (data.username !== ADMIN_USER || data.password !== ADMIN_PASS) {
      throw new Error("Invalid admin credentials");
    }
    const { data: rows, error } = await supabaseAdmin
      .from("signups")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { rows: rows ?? [] };
  });
