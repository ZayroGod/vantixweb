import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-screen text-foreground">
      <div className="bg-rgb-scene" aria-hidden />
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/40 border-b border-border">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <span className="inline-block w-8 h-8 rounded-md rgb-border" />
            <span className="text-xl font-extrabold tracking-tight text-rgb">VantixHost</span>
          </Link>
          <nav className="flex items-center gap-1 sm:gap-4 text-sm">
            <Link to="/plans" className="px-3 py-2 rounded-md hover:bg-accent/20 transition">Plans</Link>
            <Link to="/plans/minecraft" className="hidden sm:inline px-3 py-2 rounded-md hover:bg-accent/20 transition">Minecraft</Link>
            <Link to="/plans/vps" className="hidden sm:inline px-3 py-2 rounded-md hover:bg-accent/20 transition">VPS</Link>
            <Link to="/discord" className="px-3 py-2 rounded-md hover:bg-accent/20 transition">Discord</Link>
            <Link to="/admin" className="px-3 py-2 rounded-md text-muted-foreground hover:text-foreground transition">Admin</Link>
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-10">{children}</main>
      <footer className="border-t border-border mt-20">
        <div className="max-w-6xl mx-auto px-6 py-8 text-sm text-muted-foreground flex flex-col sm:flex-row gap-2 justify-between">
          <p>© {new Date().getFullYear()} <span className="text-rgb font-semibold">VantixHost</span> — Premium MC & VPS Hosting</p>
          <p>Prices in BDT (৳) & INR (₹)</p>
        </div>
      </footer>
    </div>
  );
}
