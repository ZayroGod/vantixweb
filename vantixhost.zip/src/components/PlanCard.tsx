import { Link } from "@tanstack/react-router";
import type { Plan } from "@/lib/plans";

const TIER_ICONS: Record<string, string> = {
  dirt: "🟫",
  stone: "⬜",
  diamond: "💎",
  netherite: "⬛",
  powerful: "⚡",
  shorts: "🚀",
};

export function PlanCard({ plan }: { plan: Plan }) {
  const featured = plan.tier === "diamond" || plan.tier === "netherite";
  return (
    <div className={`card-3d p-6 flex flex-col gap-4 ${featured ? "rgb-border" : ""}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-3xl">{TIER_ICONS[plan.tier]}</span>
          <h3 className="text-2xl font-bold">{plan.name}</h3>
        </div>
        <span className="text-xs uppercase tracking-wider text-muted-foreground">
          {plan.type === "minecraft" ? "MC Server" : "VPS"}
        </span>
      </div>
      <ul className="space-y-1.5 text-sm">
        <li className="flex justify-between"><span className="text-muted-foreground">RAM</span><span className="font-semibold">{plan.ram}</span></li>
        <li className="flex justify-between"><span className="text-muted-foreground">CPU</span><span className="font-semibold">{plan.cpu}</span></li>
        <li className="flex justify-between"><span className="text-muted-foreground">Disk</span><span className="font-semibold">{plan.disk}</span></li>
        {plan.extra && (
          <li className="text-xs text-accent pt-1">✓ {plan.extra}</li>
        )}
      </ul>
      <div className="pt-3 border-t border-border">
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-extrabold text-rgb">৳{plan.priceTk}</span>
          <span className="text-sm text-muted-foreground">BDT</span>
        </div>
        <div className="text-sm text-muted-foreground">₹{plan.priceInr} INR / month</div>
      </div>
      <Link to="/order/$planId" params={{ planId: plan.id }} className="btn-rgb w-full text-center">
        Order Now
      </Link>
    </div>
  );
}
